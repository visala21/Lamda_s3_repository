import boto3
import os

def lambda_handler(event, context):
    # Set the S3 bucket and object key
    bucket_name = 'my-s3-bucket-24-05-2024'
    object_key = 'lambdazipfile-1.txt'
    
    # Local path to the ZIP file to upload
    local_file_path = 'C:\Users\Dell3580\Desktop\lambda-function-zipfile.zip'
    
    # Create an S3 client
    s3_client = boto3.client('s3')
    
    try:
        # Upload the file to S3
        response = s3_client.upload_file(C:\Users\Dell3580\Desktop\lambda-function-zipfile.zip, my-s3-bucket-24-05-2024, lambdazipfile-1.txt)
        print(f"File uploaded successfully: {response}")
        return {
            'statusCode': 200,
            'body': 'File uploaded successfully'
        }
    except Exception as e:
        print(f"Failed to upload file: {e}")
        return {
            'statusCode': 500,
            'body': 'Failed to upload file'
        }